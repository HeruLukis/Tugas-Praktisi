<?php

namespace App\Http\Controllers;
use illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use illuminate\Support\Facades\DB;
class MemberController extends Controller
{
    public function card() {
        $user = Auth::user();
        return view('member.card', ['user' => $user]);
    }

    public function list() {
        $member = DB::select('select * from users');
        return view('member.listMember', ['users' => $member]);
    }
}
