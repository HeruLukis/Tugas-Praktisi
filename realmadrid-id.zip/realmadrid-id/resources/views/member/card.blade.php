@extends('_layouts.app')

@section('content')
    <h1>Tugas Praktisi</h1>
    <h1>{{ $user->name }}</h1>
@endsection