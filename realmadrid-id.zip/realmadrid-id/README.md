
## Cara install

- run "composer update"
- update .env (konfigurasi database)
- run "php artisan migrate"
