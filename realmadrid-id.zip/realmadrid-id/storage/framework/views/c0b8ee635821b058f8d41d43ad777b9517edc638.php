

<?php $__env->startSection('content'); ?>
    <h1>Heru</h1>
    <h1><?php echo e($user->name); ?></h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('_layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WebLanjut\realmadrid-id\resources\views/member/card.blade.php ENDPATH**/ ?>