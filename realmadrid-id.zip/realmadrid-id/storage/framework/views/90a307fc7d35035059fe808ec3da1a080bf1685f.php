<?php echo e($slot); ?>

<?php /**PATH D:\WebLanjut\realmadrid-id\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>